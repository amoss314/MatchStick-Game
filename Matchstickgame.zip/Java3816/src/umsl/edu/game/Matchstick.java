package umsl.edu.game;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Matchstick {

	public static void main(String[] args) {

		// Match stick game, Computer VS. User

		int userSticks;

		Scanner in = new Scanner(System.in);

		System.out.println("Hello, Let's play a game :)");
		System.out.println("There are 21 match sticks here, we pick them up until the last one is left");
		System.out.println("User starts, Choose 1,2,3 or 4");
		userSticks = in.nextInt();

		if (userSticks == 1) {
			System.out.println("Ok, I will choose 4, leaving 16 match sticks.");

		} else if (userSticks == 2) {
			System.out.println("Ok, I will choose 3, leaving 16 match sticks");

		} else if (userSticks == 3) {
			System.out.println("Ok, I will choose 2, leaving 16 match sticks");

		} else if (userSticks == 4) {
			System.out.println("Ok, I will choose 1, leaving 16 match sticks");

		} else if (userSticks > 4) {
			System.out.println("Error");

		} else if (userSticks < 1) {
			System.out.println("Error");
		}

		// I want to know how to rerun a question on a program.

		System.out.println("OK, User's turn again.");
		System.out.println("Choose 1,2,3 or 4");
		userSticks = in.nextInt();

		if (userSticks == 1) {
			System.out.println("Ok, I will choose 4, leaving 11 match sticks.");

		} else if (userSticks == 2) {
			System.out.println("Ok, I will choose 3, leaving 11 match sticks");

		} else if (userSticks == 3) {
			System.out.println("Ok, I will choose 2, leaving 11 match sticks");

		} else if (userSticks == 4) {
			System.out.println("Ok, I will choose 1, leaving 11 match sticks");

		} else if (userSticks > 4) {
			System.out.println("Error");

		} else if (userSticks < 1) {
			System.out.println("Error");
		}

		System.out.println("OK, User's turn again.");
		System.out.println("Choose 1,2,3 or 4");
		userSticks = in.nextInt();

		if (userSticks == 1) {
			System.out.println("Ok, I will choose 4, leaving 6 match sticks.");

		} else if (userSticks == 2) {
			System.out.println("Ok, I will choose 3, leaving 6 match sticks");

		} else if (userSticks == 3) {
			System.out.println("Ok, I will choose 2, leaving 6 match sticks");

		} else if (userSticks == 4) {
			System.out.println("Ok, I will choose 1, leaving 6 match sticks");

		} else if (userSticks > 4) {
			System.out.println("Error");

		} else if (userSticks < 1) {
			System.out.println("Error");
		}

		System.out.println("OK, User's turn again.");
		System.out.println("Choose 1,2,3 or 4");
		userSticks = in.nextInt();

		if (userSticks == 1) {
			System.out.println("Ok, I will choose 4, leaving 1 match stick. YOU LOSE!");

		} else if (userSticks == 2) {
			System.out.println("Ok, I will choose 3, leaving 1 match stick. YOU LOSE!");

		} else if (userSticks == 3) {
			System.out.println("Ok, I will choose 2, leaving 1 match stick. YOU LOSE!");

		} else if (userSticks == 4) {
			System.out.println("Ok, I will choose 1, leaving 1 match stick. YOU LOSE!");

		} else if (userSticks > 4) {
			System.out.println("Error");

		} else if (userSticks < 1) {
			System.out.println("Error");

		}

		String file = "GamePlayers.csv";
		Scanner scan = new Scanner(System.in);
		FileWriter fw = null;
		try {
			fw = new FileWriter(file);
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		System.out.println("What is your name for the chart?");
		String input = scan.nextLine();

		try {
			fw.write(input);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		scan.close();
		try {
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
